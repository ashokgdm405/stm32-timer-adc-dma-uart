import matplotlib.pyplot as plt
import numpy as np

# Simulate a 100Hz signal over 50ms (5 cycles)
# The timer is 100Hz, so the ADC read is 100Hz.
# Let's simulate a 10Hz sine wave being sampled at 100Hz.
sampling_rate = 100 # Hz
signal_freq = 10 # Hz
duration = 0.2 # seconds (20 samples)

t = np.linspace(0, duration, int(sampling_rate * duration), endpoint=False)
# Simulate an analog signal (e.g., a sine wave)
analog_signal = 2048 + 2047 * np.sin(2 * np.pi * signal_freq * t)

# Quantize to 12-bit ADC values (0-4095)
adc_samples = np.round(analog_signal).astype(int)
adc_samples[adc_samples > 4095] = 4095
adc_samples[adc_samples < 0] = 0

# Create the plot
plt.figure(figsize=(10, 5))

# Plot the analog signal (simulated input)
plt.plot(t * 1000, analog_signal, label='Simulated Analog Input (Volts)', color='blue', alpha=0.5)

# Plot the ADC samples (simulated output)
plt.step(t * 1000, adc_samples, where='post', label='ADC Samples (12-bit)', color='red')

# Add markers for the 100Hz timer trigger points
timer_triggers = np.arange(0, duration * 1000, 10)
plt.vlines(timer_triggers, 0, 4095, color='green', linestyle='--', linewidth=0.5, label='100Hz Timer Trigger')

plt.title('Simulated Oscilloscope Capture: 10Hz Signal Sampled at 100Hz')
plt.xlabel('Time (ms)')
plt.ylabel('ADC Value (0-4095)')
plt.ylim(0, 4095)
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.legend()
plt.savefig('simulated_scope_capture.png')
print("Simulated scope capture image generated: simulated_scope_capture.png")
