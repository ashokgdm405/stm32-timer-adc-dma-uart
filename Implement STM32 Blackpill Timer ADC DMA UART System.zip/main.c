#include "registers.h"
#include <string.h>
#include <stdio.h>

// --- Global Variables ---
#define ADC_BUFFER_SIZE 1
volatile uint16_t adc_value[ADC_BUFFER_SIZE];
volatile uint8_t tx_buffer[32];

// --- Function Prototypes ---
void SystemClock_Config(void);
void GPIO_Config(void);
void TIM2_Config(void);
void ADC1_Config(void);
void DMA2_Stream0_ADC_Config(uint16_t *buffer, uint32_t size);
void USART2_Config(void);
void DMA1_Stream6_USART_Config(uint8_t *buffer, uint32_t size);
void DMA2_Stream0_IRQHandler(void);

// --- Implementation ---

/**
 * @brief Configures the system clock to 100MHz using HSI and PLL.
 * STM32F411CEU6 HSI is 16MHz.
 * PLL_M = 8, PLL_N = 100, PLL_P = 2 -> SYSCLK = 16MHz * (100/8) / 2 = 100MHz
 */
void SystemClock_Config(void)
{
    // 1. Enable HSI
    RCC->CR |= (1 << 0); // HSION

    // 2. Configure PLL
    // PLL source is HSI (00)
    // PLL_M = 8 (Bits 5:0)
    // PLL_N = 100 (Bits 14:6)
    // PLL_P = 2 (Bits 17:16, 00)
    RCC->PLLCFGR = (0 << 22) | (0 << 16) | (100 << 6) | (8 << 0);

    // 3. Enable PLL
    RCC->CR |= (1 << 24); // PLLON

    // 4. Wait for PLL to be ready
    while (!(RCC->CR & (1 << 25))); // PLLRDY

    // 5. Configure Flash prefetch, instruction and data caches
    // Latency 3 wait states for 100MHz (Bits 3:0)
    // Enable prefetch (Bit 8), instruction cache (Bit 9), data cache (Bit 10)
    *(volatile uint32_t *)0x40023C00 |= (1 << 10) | (1 << 9) | (1 << 8) | (3 << 0);

    // 6. Configure AHB, APB1, APB2 prescalers
    // AHB Prescaler = 1 (Bits 7:4, 0xxx)
    // APB1 Prescaler = 2 (Bits 12:10, 100) -> 100MHz / 2 = 50MHz
    // APB2 Prescaler = 1 (Bits 15:13, 0xx) -> 100MHz / 1 = 100MHz
    RCC->CFGR &= ~((0xF << 4) | (0x7 << 10) | (0x7 << 13));
    RCC->CFGR |= (0x4 << 10) | (0x0 << 13); // APB1 div 2, APB2 div 1

    // 7. Select PLL as system clock source
    RCC->CFGR &= ~(0x3 << 0);
    RCC->CFGR |= (0x2 << 0); // SW = 10 (PLL selected)

    // 8. Wait for PLL to be used as system clock source
    while ((RCC->CFGR & (0x3 << 2)) != (0x2 << 2)); // SWS = 10 (PLL used)
}

/**
 * @brief Configures GPIO pins for ADC (PA0) and USART2 (PA2 TX, PA3 RX).
 */
void GPIO_Config(void)
{
    // 1. Enable GPIOA clock
    RCC->AHB1ENR |= (1 << 0); // GPIOAEN

    // 2. Configure PA0 as Analog (Mode 0b11)
    GPIOA->MODER |= (0x3 << (0 * 2));

    // 3. Configure PA2 (USART2_TX) and PA3 (USART2_RX) as Alternate Function (Mode 0b10)
    GPIOA->MODER &= ~((0x3 << (2 * 2)) | (0x3 << (3 * 2)));
    GPIOA->MODER |= (0x2 << (2 * 2)) | (0x2 << (3 * 2));

    // 4. Configure PA2 and PA3 Alternate Function to AF7 (USART2)
    // AFRL (AFR[0]) for pins 0-7
    // AF7 is 0111
    GPIOA->AFR[0] &= ~((0xF << (2 * 4)) | (0xF << (3 * 4)));
    GPIOA->AFR[0] |= (0x7 << (2 * 4)) | (0x7 << (3 * 4));
}

/**
 * @brief Configures TIM2 to generate an update event at 100Hz (10ms period).
 * System clock is 100MHz. APB1 is 50MHz. TIM2 is on APB1, so its clock is 50MHz * 2 = 100MHz (since APB1 prescaler > 1).
 * F_timer = 100MHz.
 * Period = 10ms (100Hz).
 * PSC = 9999, ARR = 99.
 * F_update = 100MHz / ((PSC + 1) * (ARR + 1)) = 100,000,000 / (10000 * 100) = 100Hz.
 */
void TIM2_Config(void)
{
    // 1. Enable TIM2 clock
    RCC->APB1ENR |= (1 << 0); // TIM2EN

    // 2. Set Prescaler and Auto-Reload Register
    TIM2->PSC = 9999; // Prescaler = 10000
    TIM2->ARR = 99;   // Auto-Reload = 100

    // 3. Configure Master Mode Selection (MMS) to Update Event (0b010)
    // This event will be used to trigger the ADC
    TIM2->CR2 &= ~(0x7 << 4);
    TIM2->CR2 |= (0x2 << 4); // MMS = 010 (Update event is selected as trigger output (TRGO))

    // 4. Enable TIM2
    TIM2->CR1 |= (1 << 0); // CEN
}

/**
 * @brief Configures ADC1 to be triggered by TIM2 and use DMA.
 */
void ADC1_Config(void)
{
    // 1. Enable ADC1 clock
    RCC->APB2ENR |= (1 << 8); // ADC1EN

    // 2. Configure ADC Common Control Register (CCR)
    // PCLK2 is 100MHz. ADC clock is PCLK2/4 = 25MHz (max 36MHz).
    ADC_COMMON->CCR &= ~(0x3 << 16); // Prescaler PCLK2/2 (00) or PCLK2/4 (01)
    ADC_COMMON->CCR |= (0x1 << 16); // Prescaler PCLK2/4 (01) -> 25MHz

    // 3. Configure ADC Control Register 2 (CR2)
    // Enable DMA (Bit 8)
    // DMA mode selection: DMA requests are generated after each conversion (Bit 9)
    // External trigger enable for regular group: Rising edge (Bits 11:10, 0b01)
    // External trigger selection for regular group: TIM2 TRGO (Bits 23:20, 0b0011)
    ADC1->CR2 |= (1 << 8) | (1 << 9) | (0x1 << 10) | (0x3 << 20);

    // 4. Configure ADC Control Register 1 (CR1)
    // Resolution 12-bit (Bits 25:24, 0b00)
    ADC1->CR1 &= ~(0x3 << 24);

    // 5. Configure Regular Sequence Register 3 (SQR3)
    // Sequence length L=0 (1 conversion) (Bits 23:20 in SQR1)
    // 1st conversion in regular sequence: Channel 0 (PA0) (Bits 4:0)
    ADC1->SQR3 = 0;
    ADC1->SQR3 |= (0 << 0); // SQ1 = Channel 0

    // 6. Configure Sample Time Register 2 (SMPR2)
    // Channel 0 sample time: 480 cycles (Bits 2:0, 0b111)
    // T_sample = 480 cycles. T_conv = 480 + 12 = 492 cycles.
    // At 25MHz, T_conv = 492 / 25,000,000 = 19.68 us.
    ADC1->SMPR2 |= (0x7 << (0 * 3));

    // 7. Enable ADC
    ADC1->CR2 |= (1 << 0); // ADON
}

/**
 * @brief Configures DMA2 Stream 0, Channel 0 for ADC1 data transfer.
 */
void DMA2_Stream0_ADC_Config(uint16_t *buffer, uint32_t size)
{
    // 1. Enable DMA2 clock
    RCC->AHB1ENR |= (1 << 22); // DMA2EN

    // 2. Disable DMA Stream 0
    DMA2_Stream0->CR &= ~(1 << 0); // EN
    while (DMA2_Stream0->CR & (1 << 0)); // Wait for EN bit to clear

    // 3. Clear all interrupt flags for Stream 0 (LIFCR)
    DMA2->LIFCR |= (0x3F << 0); // Clear all flags: CFIF, CDMEIF, CHTIF, CTCIF, CFEIF

    // 4. Configure Stream 0 Control Register (CR)
    // Channel 0 (Bits 25:23, 0b000)
    // Peripheral-to-Memory (Bits 7:6, 0b00)
    // Circular mode (Bit 8)
    // Peripheral increment disabled (Bit 9)
    // Memory increment enabled (Bit 10) - not needed for size 1, but good practice
    // Peripheral data size 16-bit (Bits 12:11, 0b01)
    // Memory data size 16-bit (Bits 14:13, 0b01)
    // High priority (Bits 17:16, 0b10)
    // Transfer Complete Interrupt Enable (Bit 4)
    DMA2_Stream0->CR = (0 << 25) | (0 << 23) | (0 << 6) | (1 << 8) | (0 << 9) | (1 << 10) |
                       (0x1 << 11) | (0x1 << 13) | (0x2 << 16) | (1 << 4);

    // 5. Configure Number of Data Register (NDTR)
    DMA2_Stream0->NDTR = size;

    // 6. Configure Peripheral Address Register (PAR)
    DMA2_Stream0->PAR = (uint32_t)&ADC1->DR;

    // 7. Configure Memory 0 Address Register (M0AR)
    DMA2_Stream0->M0AR = (uint32_t)buffer;

    // 8. Enable DMA Stream 0
    DMA2_Stream0->CR |= (1 << 0); // EN

    // 9. Enable DMA2 Stream 0 Interrupt in NVIC
    NVIC_ISER0 |= (1 << (DMA2_Stream0_IRQn - 32)); // DMA2_Stream0_IRQn is 56
}

/**
 * @brief Configures USART2 for 115200 baud, 8N1.
 * APB1 clock is 50MHz.
 * Baud Rate = F_PCLK / (8 * (2 - OVER8) * USARTDIV)
 * 115200 = 50,000,000 / (16 * USARTDIV) -> USARTDIV = 50,000,000 / (16 * 115200) = 27.1267
 * BRR = 27 * 16 + 0.1267 * 16 = 432 + 2 = 434 (0x1B2)
 */
void USART2_Config(void)
{
    // 1. Enable USART2 clock
    RCC->APB1ENR |= (1 << 17); // USART2EN

    // 2. Set Baud Rate (115200)
    // 50MHz / 115200 = 434.0277...
    // Mantissa = 434 (0x1B2)
    USART2->BRR = 0x1B2;

    // 3. Enable DMA for Transmitter (Bit 7)
    USART2->CR3 |= (1 << 7); // DMAT

    // 4. Enable Transmitter (Bit 3) and USART (Bit 13)
    USART2->CR1 |= (1 << 3) | (1 << 13); // TE, UE
}

/**
 * @brief Configures DMA1 Stream 6, Channel 4 for USART2 TX data transfer.
 */
void DMA1_Stream6_USART_Config(uint8_t *buffer, uint32_t size)
{
    // 1. Enable DMA1 clock
    RCC->AHB1ENR |= (1 << 21); // DMA1EN

    // 2. Disable DMA Stream 6
    DMA1_Stream6->CR &= ~(1 << 0); // EN
    while (DMA1_Stream6->CR & (1 << 0)); // Wait for EN bit to clear

    // 3. Clear all interrupt flags for Stream 6 (HISR/HIFCR)
    DMA1->HIFCR |= (0x3F << 22); // Clear all flags for Stream 6 (Bits 27:22)

    // 4. Configure Stream 6 Control Register (CR)
    // Channel 4 (Bits 25:23, 0b100)
    // Memory-to-Peripheral (Bits 7:6, 0b01)
    // Circular mode disabled (Bit 8)
    // Peripheral increment disabled (Bit 9)
    // Memory increment enabled (Bit 10)
    // Peripheral data size 8-bit (Bits 12:11, 0b00)
    // Memory data size 8-bit (Bits 14:13, 0b00)
    // Low priority (Bits 17:16, 0b00)
    DMA1_Stream6->CR = (4 << 23) | (1 << 6) | (0 << 8) | (0 << 9) | (1 << 10) |
                       (0x0 << 11) | (0x0 << 13) | (0x0 << 16);

    // 5. Configure Number of Data Register (NDTR)
    DMA1_Stream6->NDTR = size;

    // 6. Configure Peripheral Address Register (PAR)
    DMA1_Stream6->PAR = (uint32_t)&USART2->DR;

    // 7. Configure Memory 0 Address Register (M0AR)
    DMA1_Stream6->M0AR = (uint32_t)buffer;

    // Note: DMA is not enabled here. It will be enabled in the ADC DMA ISR.
}

/**
 * @brief DMA2 Stream 0 Interrupt Handler (for ADC Transfer Complete).
 */
void DMA2_Stream0_IRQHandler(void)
{
    // Check for Transfer Complete Interrupt Flag (TCIF0)
    if (DMA2->LISR & (1 << 5))
    {
        // 1. Clear the Transfer Complete Flag
        DMA2->LIFCR |= (1 << 5); // CTCIF0

        // 2. Format the ADC result into the TX buffer
        int len = snprintf((char *)tx_buffer, sizeof(tx_buffer), "ADC: %hu\r\n", adc_value[0]);

        // 3. Configure and start the USART2 TX DMA transfer
        // Re-configure NDTR and M0AR (M0AR is already set, but NDTR needs to be set for the new length)
        DMA1_Stream6->NDTR = len;
        DMA1_Stream6->M0AR = (uint32_t)tx_buffer;

        // 4. Enable DMA1 Stream 6 to start transmission
        DMA1_Stream6->CR |= (1 << 0); // EN
    }
}

int main(void)
{
    // 1. Configure System Clock
    SystemClock_Config();

    // 2. Configure Peripherals
    GPIO_Config();
    USART2_Config();
    TIM2_Config();
    ADC1_Config();

    // 3. Configure DMA for ADC (Circular mode)
    DMA2_Stream0_ADC_Config((uint16_t *)adc_value, ADC_BUFFER_SIZE);

    // 4. Configure DMA for USART TX (will be triggered in ISR)
    // Initial configuration with a dummy size, will be updated in ISR
    DMA1_Stream6_USART_Config((uint8_t *)tx_buffer, 0);

    // 5. Start ADC conversion (it will be continuously triggered by TIM2)
    ADC1->CR2 |= (1 << 30); // SWSTART (This is not strictly needed as TIM2 will trigger, but ensures a start)

    // Main loop: wait for interrupts
    while (1)
    {
        // The work is done in the DMA ISR
    }
}

// Minimal startup file replacement (for a simple bare-metal build)
// This is a placeholder and would be replaced by a proper startup.s file in a real project.
// For the purpose of this task, I will assume the build system handles the vector table.
// I will need to ensure the linker script points to this main function.
// For the current environment, I will rely on the fact that I only need to provide the C code.
// The key is the ISR name, which must match the vector table entry.
// The actual vector table is defined in the startup file, which is not part of the C code.
// I will proceed with the C code and assume a standard F411 startup file is used.
// The function name DMA2_Stream0_IRQHandler is the standard name.
