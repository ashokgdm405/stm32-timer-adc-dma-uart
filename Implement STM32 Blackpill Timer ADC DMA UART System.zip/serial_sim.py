'''
import time

for i in range(10):
    # Simulate a 12-bit ADC value (0-4095)
    adc_value = 1024 + (i * 100) % 3072
    print(f"ADC: {adc_value}")
    time.sleep(0.01) # 100Hz
'''
