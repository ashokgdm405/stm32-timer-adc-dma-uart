#ifndef REGISTERS_H
#define REGISTERS_H

#include <stdint.h>

// Base addresses for AHB1 Peripherals
#define PERIPH_BASE           (0x40000000UL)
#define AHB1PERIPH_BASE       (PERIPH_BASE + 0x00020000UL)
#define RCC_BASE              (AHB1PERIPH_BASE + 0x3800UL)
#define GPIOA_BASE            (AHB1PERIPH_BASE + 0x0000UL)
#define DMA1_BASE             (AHB1PERIPH_BASE + 0x6000UL)
#define DMA2_BASE             (AHB1PERIPH_BASE + 0x6400UL)

// Base addresses for APB1 Peripherals
#define APB1PERIPH_BASE       (PERIPH_BASE)
#define USART2_BASE           (APB1PERIPH_BASE + 0x4400UL)
#define TIM2_BASE             (APB1PERIPH_BASE + 0x0000UL)

// Base addresses for APB2 Peripherals
#define APB2PERIPH_BASE       (PERIPH_BASE + 0x00010000UL)
#define ADC1_BASE             (APB2PERIPH_BASE + 0x2000UL)

// RCC Register Structure
typedef struct
{
  volatile uint32_t CR;         /*!< RCC clock control register,                                    Address offset: 0x00 */
  volatile uint32_t PLLCFGR;    /*!< RCC PLL configuration register,                                Address offset: 0x04 */
  volatile uint32_t CFGR;       /*!< RCC clock configuration register,                              Address offset: 0x08 */
  volatile uint32_t CIR;        /*!< RCC clock interrupt register,                                  Address offset: 0x0C */
  volatile uint32_t AHB1RSTR;   /*!< RCC AHB1 peripheral reset register,                            Address offset: 0x10 */
  volatile uint32_t AHB2RSTR;   /*!< RCC AHB2 peripheral reset register,                            Address offset: 0x14 */
  volatile uint32_t AHB3RSTR;   /*!< RCC AHB3 peripheral reset register,                            Address offset: 0x18 */
  uint32_t      RESERVED0;    /*!< Reserved, 0x1C                                                                    */
  volatile uint32_t APB1RSTR;   /*!< RCC APB1 peripheral reset register,                            Address offset: 0x20 */
  volatile uint32_t APB2RSTR;   /*!< RCC APB2 peripheral reset register,                            Address offset: 0x24 */
  uint32_t      RESERVED1[2]; /*!< Reserved, 0x28-0x2C                                                               */
  volatile uint32_t AHB1ENR;    /*!< RCC AHB1 peripheral clock enable register,                     Address offset: 0x30 */
  volatile uint32_t AHB2ENR;    /*!< RCC AHB2 peripheral clock enable register,                     Address offset: 0x34 */
  volatile uint32_t AHB3ENR;    /*!< RCC AHB3 peripheral clock enable register,                     Address offset: 0x38 */
  uint32_t      RESERVED2;    /*!< Reserved, 0x3C                                                                    */
  volatile uint32_t APB1ENR;    /*!< RCC APB1 peripheral clock enable register,                     Address offset: 0x40 */
  volatile uint32_t APB2ENR;    /*!< RCC APB2 peripheral clock enable register,                     Address offset: 0x44 */
  uint32_t      RESERVED3[2]; /*!< Reserved, 0x48-0x4C                                                               */
  volatile uint32_t AHB1LPENR;  /*!< RCC AHB1 peripheral low power clock enable register,           Address offset: 0x50 */
  volatile uint32_t AHB2LPENR;  /*!< RCC AHB2 peripheral low power clock enable register,           Address offset: 0x54 */
  volatile uint32_t AHB3LPENR;  /*!< RCC AHB3 peripheral low power clock enable register,           Address offset: 0x58 */
  uint32_t      RESERVED4;    /*!< Reserved, 0x5C                                                                    */
  volatile uint32_t APB1LPENR;  /*!< RCC APB1 peripheral low power clock enable register,           Address offset: 0x60 */
  volatile uint32_t APB2LPENR;  /*!< RCC APB2 peripheral low power clock enable register,           Address offset: 0x64 */
  uint32_t      RESERVED5[2]; /*!< Reserved, 0x68-0x6C                                                               */
  volatile uint32_t BDCR;       /*!< RCC Backup domain control register,                            Address offset: 0x70 */
  volatile uint32_t CSR;        /*!< RCC clock control & status register,                           Address offset: 0x74 */
  uint32_t      RESERVED6[2]; /*!< Reserved, 0x78-0x7C                                                               */
  volatile uint32_t SSCGR;      /*!< RCC spread spectrum clock generation register,                 Address offset: 0x80 */
  volatile uint32_t PLLI2SCFGR; /*!< RCC PLLI2S configuration register,                             Address offset: 0x84 */
  volatile uint32_t DCKCFGR;    /*!< RCC Dedicated Clocks configuration register,                   Address offset: 0x88 */
} RCC_TypeDef;

#define RCC                 ((RCC_TypeDef *) RCC_BASE)

// GPIO Register Structure (simplified)
typedef struct
{
  volatile uint32_t MODER;      /*!< GPIO port mode register,                 Address offset: 0x00      */
  volatile uint32_t OTYPER;     /*!< GPIO port output type register,          Address offset: 0x04      */
  volatile uint32_t OSPEEDR;    /*!< GPIO port output speed register,         Address offset: 0x08      */
  volatile uint32_t PUPDR;      /*!< GPIO port pull-up/pull-down register,    Address offset: 0x0C      */
  volatile uint32_t IDR;        /*!< GPIO port input data register,           Address offset: 0x10      */
  volatile uint32_t ODR;        /*!< GPIO port output data register,          Address offset: 0x14      */
  volatile uint32_t BSRR;       /*!< GPIO port bit set/reset register,        Address offset: 0x18      */
  volatile uint32_t LCKR;       /*!< GPIO port configuration lock register,   Address offset: 0x1C      */
  volatile uint32_t AFR[2];     /*!< GPIO alternate function low/high register, Address offset: 0x20-0x24 */
} GPIO_TypeDef;

#define GPIOA               ((GPIO_TypeDef *) GPIOA_BASE)

// TIM Register Structure (simplified for TIM2)
typedef struct
{
  volatile uint32_t CR1;        /*!< TIM control register 1,                      Address offset: 0x00 */
  volatile uint32_t CR2;        /*!< TIM control register 2,                      Address offset: 0x04 */
  volatile uint32_t SMCR;       /*!< TIM slave mode control register,             Address offset: 0x08 */
  volatile uint32_t DIER;       /*!< TIM DMA/interrupt enable register,           Address offset: 0x0C */
  volatile uint32_t SR;         /*!< TIM status register,                         Address offset: 0x10 */
  volatile uint32_t EGR;        /*!< TIM event generation register,               Address offset: 0x14 */
  volatile uint32_t CCMR1;      /*!< TIM capture/compare mode register 1,         Address offset: 0x18 */
  volatile uint32_t CCMR2;      /*!< TIM capture/compare mode register 2,         Address offset: 0x1C */
  volatile uint32_t CCER;       /*!< TIM capture/compare enable register,         Address offset: 0x20 */
  volatile uint32_t CNT;        /*!< TIM counter register,                        Address offset: 0x24 */
  volatile uint32_t PSC;        /*!< TIM prescaler register,                      Address offset: 0x28 */
  volatile uint32_t ARR;        /*!< TIM auto-reload register,                    Address offset: 0x2C */
  volatile uint32_t RCR;        /*!< TIM repetition counter register,             Address offset: 0x30 */
  volatile uint32_t CCR1;       /*!< TIM capture/compare register 1,              Address offset: 0x34 */
  volatile uint32_t CCR2;       /*!< TIM capture/compare register 2,              Address offset: 0x38 */
  volatile uint32_t CCR3;       /*!< TIM capture/compare register 3,              Address offset: 0x3C */
  volatile uint32_t CCR4;       /*!< TIM capture/compare register 4,              Address offset: 0x40 */
  volatile uint32_t DCR;        /*!< TIM DMA control register,                    Address offset: 0x48 */
  volatile uint32_t DMAR;       /*!< TIM DMA address for full transfer,           Address offset: 0x4C */
  volatile uint32_t OR;         /*!< TIM option register,                         Address offset: 0x50 */
} TIM_TypeDef;

#define TIM2                ((TIM_TypeDef *) TIM2_BASE)

// ADC Register Structure (simplified for ADC1)
typedef struct
{
  volatile uint32_t SR;         /*!< ADC status register,                         Address offset: 0x00 */
  volatile uint32_t CR1;        /*!< ADC control register 1,                      Address offset: 0x04 */
  volatile uint32_t CR2;        /*!< ADC control register 2,                      Address offset: 0x08 */
  volatile uint32_t SMPR1;      /*!< ADC sample time register 1,                  Address offset: 0x0C */
  volatile uint32_t SMPR2;      /*!< ADC sample time register 2,                  Address offset: 0x10 */
  volatile uint32_t JOFR1;      /*!< ADC injected channel data offset register 1, Address offset: 0x14 */
  volatile uint32_t JOFR2;      /*!< ADC injected channel data offset register 2, Address offset: 0x18 */
  volatile uint32_t JOFR3;      /*!< ADC injected channel data offset register 3, Address offset: 0x1C */
  volatile uint32_t JOFR4;      /*!< ADC injected channel data offset register 4, Address offset: 0x20 */
  volatile uint32_t HTR;        /*!< ADC high threshold register,                 Address offset: 0x24 */
  volatile uint32_t LTR;        /*!< ADC low threshold register,                  Address offset: 0x28 */
  volatile uint32_t SQR1;       /*!< ADC regular sequence register 1,             Address offset: 0x2C */
  volatile uint32_t SQR2;       /*!< ADC regular sequence register 2,             Address offset: 0x30 */
  volatile uint32_t SQR3;       /*!< ADC regular sequence register 3,             Address offset: 0x34 */
  volatile uint32_t JSQR;       /*!< ADC injected sequence register,              Address offset: 0x38 */
  volatile uint32_t JDR1;       /*!< ADC injected data register 1,                Address offset: 0x3C */
  volatile uint32_t JDR2;       /*!< ADC injected data register 2,                Address offset: 0x40 */
  volatile uint32_t JDR3;       /*!< ADC injected data register 3,                Address offset: 0x44 */
  volatile uint32_t JDR4;       /*!< ADC injected data register 4,                Address offset: 0x48 */
  volatile uint32_t DR;         /*!< ADC regular data register,                   Address offset: 0x4C */
} ADC_TypeDef;

#define ADC1                ((ADC_TypeDef *) ADC1_BASE)

// ADC Common Register Structure (simplified)
typedef struct
{
  volatile uint32_t CSR;        /*!< ADC Common status register,                  Address offset: ADC1_BASE + 0x300 */
  volatile uint32_t CCR;        /*!< ADC Common control register,                 Address offset: ADC1_BASE + 0x304 */
  volatile uint32_t CDR;        /*!< ADC Common regular data register,            Address offset: ADC1_BASE + 0x308 */
} ADC_Common_TypeDef;

#define ADC_COMMON_BASE     (ADC1_BASE + 0x300UL)
#define ADC_COMMON          ((ADC_Common_TypeDef *) ADC_COMMON_BASE)

// DMA Stream Register Structure (simplified for DMA2 Stream 0)
typedef struct
{
  volatile uint32_t CR;         /*!< DMA stream x configuration register      */
  volatile uint32_t NDTR;       /*!< DMA stream x number of data register     */
  volatile uint32_t PAR;        /*!< DMA stream x peripheral address register */
  volatile uint32_t M0AR;       /*!< DMA stream x memory 0 address register   */
  volatile uint32_t M1AR;       /*!< DMA stream x memory 1 address register   */
  volatile uint32_t FCR;        /*!< DMA stream x FIFO control register       */
} DMA_Stream_TypeDef;

// DMA Register Structure (simplified for DMA2)
typedef struct
{
  volatile uint32_t LISR;       /*!< DMA low interrupt status register,      Address offset: 0x00 */
  volatile uint32_t HISR;       /*!< DMA high interrupt status register,     Address offset: 0x04 */
  volatile uint32_t LIFCR;      /*!< DMA low interrupt flag clear register,  Address offset: 0x08 */
  volatile uint32_t HIFCR;      /*!< DMA high interrupt flag clear register, Address offset: 0x0C */
  DMA_Stream_TypeDef S[8];      /*!< DMA Stream registers,                   Address offset: 0x10-0x108 */
} DMA_TypeDef;

#define DMA1                ((DMA_TypeDef *) DMA1_BASE)
#define DMA2                ((DMA_TypeDef *) DMA2_BASE)
#define DMA2_Stream0        ((DMA_Stream_TypeDef *) (DMA2_BASE + 0x10UL + (0 * 0x18UL))) // DMA2 Stream 0 (ADC)
#define DMA1_Stream6        ((DMA_Stream_TypeDef *) (DMA1_BASE + 0x10UL + (6 * 0x18UL))) // DMA1 Stream 6 (USART2_TX)

// USART Register Structure (simplified for USART2)
typedef struct
{
  volatile uint32_t SR;         /*!< USART Status register,                    Address offset: 0x00 */
  volatile uint32_t DR;         /*!< USART Data register,                      Address offset: 0x04 */
  volatile uint32_t BRR;        /*!< USART Baud rate register,                 Address offset: 0x08 */
  volatile uint32_t CR1;        /*!< USART Control register 1,                 Address offset: 0x0C */
  volatile uint32_t CR2;        /*!< USART Control register 2,                 Address offset: 0x10 */
  volatile uint32_t CR3;        /*!< USART Control register 3,                 Address offset: 0x14 */
  volatile uint32_t GTPR;       /*!< USART Guard time and prescaler register,  Address offset: 0x18 */
} USART_TypeDef;

#define USART2              ((USART_TypeDef *) USART2_BASE)

// NVIC (Nested Vectored Interrupt Controller) - simplified
#define NVIC_BASE           (0xE000E100UL)
#define NVIC_ISER0          (*(volatile uint32_t *)(NVIC_BASE + 0x000UL)) // Interrupt Set-Enable Register 0
#define NVIC_ICER0          (*(volatile uint32_t *)(NVIC_BASE + 0x080UL)) // Interrupt Clear-Enable Register 0

// Interrupt Numbers (IRQs)
#define DMA2_Stream0_IRQn   56
#define DMA1_Stream6_IRQn   17

// Function prototypes for system setup
void SystemClock_Config(void);
void GPIO_Config(void);
void TIM2_Config(void);
void ADC1_Config(void);
void DMA2_Stream0_ADC_Config(uint16_t *buffer, uint32_t size);
void USART2_Config(void);
void DMA1_Stream6_USART_Config(uint8_t *buffer, uint32_t size);



#endif // REGISTERS_H
